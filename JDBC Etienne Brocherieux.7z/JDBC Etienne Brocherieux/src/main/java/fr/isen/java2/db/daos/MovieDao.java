package fr.isen.java2.db.daos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import fr.isen.java2.db.entities.Genre;
import fr.isen.java2.db.entities.Movie;

public class MovieDao {

/*   ------------------------------------------------------------------------   */
	public List<Movie> listMovies() {
		List<Movie> listMovies = new ArrayList<>();

		try (Connection connection = DataSourceFactory.getDataSource().getConnection();
			 PreparedStatement statement = connection.prepareStatement("SELECT * FROM movie INNER JOIN genre ON movie.genre_id=genre.idgenre");
			 ResultSet results = statement.executeQuery()) {

			while (results.next()) {
				Movie movie = new Movie(
						results.getInt("idmovie"),
						results.getString("title"),
						results.getDate("release_date").toLocalDate(),
						new Genre(results.getInt("idgenre"), results.getString("name")).getId(),
						results.getInt("duration"),
						results.getString("director"),
						results.getString("summary"));

				listMovies.add(movie);}
			return listMovies;
		}

		catch (SQLException e) {
			throw new RuntimeException("Error occurred while fetching the list of movies.",e);
		}
	}

/*   ------------------------------------------------------------------------   */

	public List<Movie> listMoviesByGenre(String genreName) {
		List<Movie> listMovies = new ArrayList<>();

		try (Connection connection = DataSourceFactory.getDataSource().getConnection();
			 // Select the film(s) that seems the genreName, if we want to see comedy films, we will see all types of Comedy (Horror-Comedy, Thriller-Comedy..)
			 PreparedStatement statement_listByGenre = connection.prepareStatement("SELECT * FROM movie INNER JOIN genre ON movie.genre_id=genre.idgenre WHERE genre.name LIKE ?");)
		{
			statement_listByGenre.setString(1, "%" + genreName + "%");
			ResultSet results = statement_listByGenre.executeQuery();

			while (results.next()) {
				Movie movie = new Movie(
						results.getInt("idmovie"),
						results.getString("title"),
						results.getDate("release_date").toLocalDate(),
						new Genre(results.getInt("idgenre"), results.getString("name")).getId(),
						results.getInt("duration"),
						results.getString("director"),
						results.getString("summary"));

				listMovies.add(movie);}
			return listMovies;
		}

		catch (SQLException e) {
			throw new RuntimeException("Error occurred while fetching the list of movies by genre.",e);
		}
	}

/*   ------------------------------------------------------------------------   */

	public void addMovie(Movie movie) {
		try (Connection connection = DataSourceFactory.getDataSource().getConnection();
		 	// Check if the genre of the movie we want to add exists
			 PreparedStatement statement_IsGenreExist = connection.prepareStatement("SELECT idgenre FROM genre WHERE idgenre=?");
		 	// Insert movie
		 	 PreparedStatement statement_addMovie = connection.prepareStatement("INSERT INTO movie (title, release_date, genre_id, duration, director, summary) VALUES (?, ?, ?, ?, ?, ?)"))
		{
			statement_IsGenreExist.setInt(1, movie.getGenre());
			ResultSet IsGenreExist = statement_IsGenreExist.executeQuery();

		// Genre exists
			if(IsGenreExist.next()){
				/*        ^  set parameters to the query  ^        */
				statement_addMovie.setString(1, movie.getTitle());
				statement_addMovie.setString(2, movie.getReleaseDate().toString());
				statement_addMovie.setInt(3, movie.getGenre());
				statement_addMovie.setInt(4, movie.getDuration());
				statement_addMovie.setString(5, movie.getDirector());
				statement_addMovie.setString(6, movie.getSummary());
				statement_addMovie.executeUpdate();
			}
		// Genre doesn't exists
			else
				System.out.println("This idgenre doesn't exist.");
		} catch (SQLException e) {
			throw new RuntimeException("Error occured while adding a movie.",e);
		}
	}
}